



import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        useOfReduce()
    }
    
    func useOfInitRepeatingCount(){
        
        // Creates a new string/Character representing the given string repeated the specified number of times.
        //repeating method
        let s = String(repeating: "ab", count: 10)
        print("repeating String = \(s)")
        //abababababababababab
        
    }
    
    func useOfEmptyAndCount(){
        
        //isEmptyMethod
        //A Boolean value indicating whether a string has no characters.
        let s = "India"
        if s.isEmpty{
            print("String is Empty")
        }else{
            print("String not Empty")
        }
        
        //The number of characters in a string.
        print("No of characters = \(s.count)")
        
        
        /*
         To check whether a string is empty, use its isEmpty property instead of comparing the length of one of the views to 0. Unlike with isEmpty, calculating a view’s count property requires iterating through the elements of the string.
         because isEmpty check first element
         and count check all element and count it so it is slow
         */
        
    }
    
    func useOfConvertDataAndViceVersa(){
        //String to Data(bytes)
        let aStr = "Hello World"
        
        let aStrData = aStr.data(using: .utf8)
        print("data from String = \(aStrData)")//Optional(11 bytes)
        
        
        // Data(bytes) to String
        let bStr = String(data: aStrData!, encoding: .utf8)
        print("string from data = \(bStr)")//Optional("Hello World")
    }
    
    func useOfInitFormat(){
        //Leading Zeros
        let number: Int = 7
        let str1 = String(format: "%03d", number) // 007
        let str2 = String(format: "%05d", number) // 00007
        print("str1 = \(str1)")
        print("str2 = \(str2)")
        
    }
    
    func useOfWriteTo(){
        
        //write method
        
        //write a file
        let str = "Super long string here"
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)//path of document
        ///Users/abc/Library/Developer/CoreSimulator/Devices/3B337CE2-4D13-4A2F-B630-F6F276060031/data/Containers/Data/Application/29646DF6-7BBF-415F-B970-483DD0D39F11/Documents/
        
        
        let filename = paths[0].appendingPathComponent("output.txt")
        print(filename)
        /////Users/abc/Library/Developer/CoreSimulator/Devices/3B337CE2-4D13-4A2F-B630-F6F276060031/data/Containers/Data/Application/29646DF6-7BBF-415F-B970-483DD0D39F11/Documents/output.txt
        
        do {
            try str.write(to: filename, atomically: true, encoding: String.Encoding.utf8)
        } catch {
            // failed to write file – bad permissions, bad filename, missing permissions, or more likely it can't be converted to the encoding
        }
    }
    
    func useOfAppendContentOf(){
        // append
        
        var str = "Hello"
        str.append(contentsOf: "world") //same as append
        print("Append Content of string = \(str)")
        
    }
    
    func useOfWriteAndAppend(){
        // Appends the given string to this string.
        var str = "Hello"
        
        str.append("world")
        print("Append String = \(str)")
        
        str.write("seo")//same as append
        print("write string = \(str)")
    }
    
    func useOfAppendSequence(){
        // Adds the elements of a sequence or collection to the end of this collection.
        
        var numbers = [1, 2, 3, 4, 5]
        numbers.append(contentsOf: 10...15)
        print("use of append sequence = \(numbers)")
        
    }
    
    func useOfStaticPlus(){
        //return
        //basically use of concatenation
        var lhsStr = "LHS"
        let rhsStr = "RHS"
        
        let firstString = lhsStr + rhsStr
        print("simple + = \(firstString)")
      
        lhsStr += rhsStr
        print("simple += = \(lhsStr)")
        
        // Creates a new collection by concatenating the elements of a sequence and a collection.
        // use a += b in generic function is working  but a + b is not working for string as well as int
        var numbers = [1, 2, 3, 4, 5]
        numbers += 10...15 // but possible
        print(numbers)
        
    }
    
    func useOfLowerAndUpperCase(){
        let cafe = "BBQ Café 🍵"
        print("lower case = \(cafe.lowercased())")
        print("upper case = \(cafe.uppercased())")
        
    }
    
    func useOfFindingSubstrings(){
        //        Returns a Boolean value indicating whether the string begins with the specified prefix.
        let cafe = "Café du Monde"
        print(cafe.hasPrefix("café")) // case sensitive//false
        print(cafe.hasPrefix("Café"))//true
        
        //        Returns a Boolean value indicating whether the string ends with the specified suffix.
        let plans = "Let's meet at the café"
        print(plans.hasSuffix("café")) // case sensitive//true
        print(plans.hasSuffix("Café"))//false
    }
    
    func useOfFindingCharacters(){
        //        Returns a Boolean value indicating whether the sequence contains the given element.
        
        //contains
        let str = "Hello world"
        print("string = \(str.contains("r"))")//true
        
        let stringArray = ["Vivien", "Marlon", "Kim", "Karl"]
        print("string array = \(stringArray.contains("Marlon"))")//true
        
    }
    
    func useOfShuffled(){
        //        Returns the elements of the sequence, shuffled.
        //        For example, you can shuffle the numbers between 0 and 9 by calling the shuffled() method on that range:
        let numbers = 0...9
        let shuffledNumbers = numbers.shuffled()
        print("shuffled number = \(shuffledNumbers)")//[1, 9, 8, 3, 4, 7, 2, 5, 6, 0]
    }
    
    func useOfReversed(){
        // Returns a view presenting the elements of the collection in reverse order.
        //You can reverse a collection without allocating new space for its elements by calling this reversed() method. A ReversedCollection instance wraps an underlying collection and provides access to its elements in reverse order. This example prints the characters of a string in reverse order:
        let word = "Backwards"
        for char in word.reversed(){
            print(char, terminator: "")
        }
        let reversedWord = String(word.reversed())
        print(reversedWord)
    }
    
    func useOfEnumerated(){
        //        Returns a sequence of pairs (n, x), where n represents a consecutive integer starting at zero and x represents an element of the sequence.
        //        This example enumerates the characters of the string “Swift” and prints each character along with its place in the string.
        for (index, value) in "Swift".enumerated(){
            print("index = \(index), value = \(value)")
        }
    }
    
    func useOfForEach(){
        //        Calls the given closure on each element in the sequence in the same order as a for-in loop.
        //for in
        let numberWords = ["one", "two", "three"]
        for word in numberWords {
            print(word)
        }
        //for each
        numberWords.forEach { (word) in
            print(word)
        }
    }
    
    func useOfRandomElement(){
        //Call randomElement() to select a random element from an array or another collection. This example picks a name at random from an array:
        let names = ["Zoey", "Chloe", "Amani", "Amaia"]
        let randomName = names.randomElement()!
        print("Random element = \(randomName)")
    }
    
    func useOfInsertAt(){
        // Inserts a new character at the specified position.
        var str = "ABCD"
        
        str.insert("Y", at: str.index(str.startIndex, offsetBy: 2))
        str.insert("Z", at: str.startIndex)
        // it is not use int value because some string get unicode value so it count the 1 index like smily etc.
        
        print("Insert in string = \(str)")//ZABYCD
        
        var strArray = ["A", "B", "C", "D"]
        strArray.insert("Z", at: 2)
        print("insert in string array = \(strArray)")//["A", "B", "Z", "C", "D"]
        
        //Inserts the elements of a sequence into the collection at the specified position.
        
        var numbers = [1, 2, 3, 4, 5]
        numbers.insert(contentsOf: 100...103, at: 3)//[1, 2, 3, 100, 101, 102, 103, 4, 5]
        print(numbers)
    }
    
    func useOfRemove(){
        //Removes and returns the character at the specified position.
        var nonempty = "non-emp-ty"
        if let i = nonempty.firstIndex(of: "-") {
            nonempty.remove(at: i)
        }
        print("Remove At = \(nonempty)")//nonemp-ty
        
        //Replaces this string with the empty string. and both are same
        var empty = "ghghg"
        empty.removeAll()
        print("remove all = \(empty)")
        
        //Removes all the elements that satisfy the given predicate.
        var phrase = "The rain in Spain stays mainly in the plain."
      
        let vowels: Set<Character> = ["a", "e", "i", "o", "u"]
       
        phrase.removeAll { (first) -> Bool in
            return vowels.contains(first)
        }
        
        print("remove vowels = \(phrase)")//Th rn n Spn stys mnly n th pln.
        
        
        //Removes and returns the first element of the collection.
        var bugs = ["Aphid", "Bumblebee", "Cicada", "Damselfly", "Earwig"]
        bugs.removeFirst()
        print("Remove first = \(bugs)")//["Bumblebee", "Cicada", "Damselfly", "Earwig"]
        
        //Removes the specified number of elements from the beginning of the collection.
        bugs.removeFirst(2)
        print("Remove first 2 = \(bugs)")//["Damselfly", "Earwig"]
        
        //Removes and returns the last element of the collection.
        var bugsLast = ["Aphid", "Bumblebee", "Cicada", "Damselfly", "Earwig"]
        bugsLast.removeLast()
        print("Remove last = \(bugsLast)")//["Aphid", "Bumblebee", "Cicada", "Damselfly"]
        
        //Removes the specified number of elements from the ending of the collection.
        bugsLast.removeLast(2)
        print("Remove last 2 = \(bugsLast)")//["Aphid", "Bumblebee"]
        
        //Removes the elements in the specified subrange from the collection.
        var nums = [10, 20, 30, 40, 50]
        nums.removeSubrange(1...3)
        print("use with array = \(nums)")//[10, 50]
        
        //Removes the characters in the given range.
        var strHelloWorld = "Hello world"
        let range = strHelloWorld.range(of: "w")
        strHelloWorld.removeSubrange(range!)
        print("use with strings = \(strHelloWorld)")//Hello orld
        
    }
    
    func useOfSorted(){
        //Returns the elements of the sequence, sorted.
        //You can sort any sequence of elements that conform to the Comparable protocol by calling this method. Elements are sorted in ascending order.
        //
        //Here’s an example of sorting a list of students’ names. Strings in Swift conform to the Comparable protocol, so the names are sorted in ascending order according to the less-than operator (<).
        let students = ["Kofi", "Abena", "Peter", "Kweku", "Akosua"]
       
        let sortedStudents = students.sorted()
        
        print(sortedStudents)
      
        let descendentStudents = students.sorted { (first, second) -> Bool in
            return first > second
        }
        print(descendentStudents)
        
    }
    
    func useOfReduce(){
        //Use the reduce(_:_:) method to produce a single value from the elements of an entire sequence. For example, you can use this method on an array of numbers to find their sum or product.
        let numbers = [1, 2, 3, 4]
        let numberSum = numbers.reduce(50) { (sum, x) -> Int in
            return sum + x
        }
        print("reduced = \(numberSum)")
    }
    
}


